# New-Compuer-Initializor

Download all the files and then run the "Initialize.bat" File. Follow the prompts as they come.

### Please Note:

It is **important** that you wait for the installers to finish before moving on in the prompts. 
Also, you need to extract the folder from the zip file in order for it to be able to run and execute properly. 
